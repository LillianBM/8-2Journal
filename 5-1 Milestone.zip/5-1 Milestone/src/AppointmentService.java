import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class AppointmentService {
	private List<Appointment> appointments;
	
	public AppointmentService() {
		appointments = new ArrayList<>();
		
	}
	//Method that will add an appointmnet.
	public void addAppointment(Appointment appointment) {
		appointments.add(appointment);
		
	}
	//method that will delete an appopintment by appointmentID
	public void deleteAppointment(String appointmentID) {
		appointments.removeIf(appointment -> appointment.getAppointmentID().equals(appointmentID));
	}

}
