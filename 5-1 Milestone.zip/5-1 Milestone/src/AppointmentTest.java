import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class AppointmentTest {
	@Test
	public void testGetters() {
		//the test data 
		String appointmentID = "1234567890";
		String description = "Test Appointmnet";
		Appointment appointment = new Appointment(appointmentID, new Date(), description);
		
		//test the getters
		assertEquals(appointmentID, appointment.getAppointmentID());
		assertEquals(description, appointmnet.getDescription());
	}

}
