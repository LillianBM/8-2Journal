import java.util.Date;
public class Appointment {
	private final String appointmentID;
	private final Date appointmentDate;
	private final String description;
	
	public Appointment(String appointmentID, Date appointmentData, String description) {
		this.appointmentID = appointmentID;
		this.appointmentDate = appointmentDate;
		this.description = description;
	}
	//Getter for the appointmentID 
	public String getAppointmentID() {
		return appointmentID;
	}
	//A getter for appointmentDate 
	public Date getAppointmentDate() {
		return appointmentDate;
	}
	//Getter for description
	public String getDescription() {
		return description;
	}

}
