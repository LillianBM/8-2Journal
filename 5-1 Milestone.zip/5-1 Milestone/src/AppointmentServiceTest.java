import org.junit.Before;
import org.junit.Test;
import java.util.Date;

import static org.junit.Assert.assertEquals;

public class AppointmentServiceTest {
	private AppointmentService appointmentService;
	
	@Before 
	public void setUP() {
		//create a new instance of the appointmentService before each test
		appointmentService = new AppointmentService();
		
	}
	@Test 
	public void testAddAppointment() {
		//testing the data
		String appointmentID = "1234567890";
		String description = "Test Appointment";
		Appointment appointment = new Appointment(appointmentID, new Date(), description);
		
		//adding the appointment to the service.
		appointmentService.addAppointment(appointment);
		
		//checking if the appointment was added successfully.
		assertEquals(1, appointmentService.getAppointments().size());
		
		
	}
	@Test
	public void testDeleteAppointment() {
		//testing data
		String appointmentID = "1234567890";
		String description = "Test Appointmnet";
		Appointment appointment = new Appointment(appointmentID, new Date(), description);
		
		// addimg the appointment to the service 
		appointmentService.addAppointment(appointment);
		
		// check to see if the appointment was added.
		assertEquals(1, appointmentService.getAppointments().size());
		
		//Delete the appointment using its ID
		appointmentService.deleteAppointment(appointmentID);
		
		//check if the appointment was deleted correctly.
		assertEquals(0, appointmentService.getAppointments().size());
	}

}
