import org.junit.*;
public class TaskTest {
	@Test
	public void createValidTask() {
		Task task = new Task("1", "Task 1", "Description 1");
		Assert.assertEquals("1", task.getTaskId());
		Assert.assertEquals("Task 1", task.getName());
		Assert.assertEquals("Description 1", task.getDescription());
	}
// any additional cases that will validate various constraints.
}
