import org.junit.*;
public class TaskServiceTest {
	private TaskService taskService;
	
	@Before
	public void set() {
		taskService = new TaskService();
		
	}
	@Test
	public void addValidTask() {
		taskService.addTask("1", "Task 1", "Description 1");
	}
	//for additional test casses to help validate add, update and delete operations and constraints. 

}
