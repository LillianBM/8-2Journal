
public class Contact {
	// define the Contact class
		private String contactID;
		private String firstName;
		private String lastName;
		private String phone;
		private String address;
		
		//constructor to initialize contact details
		public Contact(String contactID, String firstName, String lastName, String phone, String address) {
			this.contactID = contactID;
			this.firstName = firstName;
			this.lastName = lastName;
			this.phone = phone;
			this.address = address;
		}
		// getter methods for accessing contact details
		// method to get contact ID
		public String getContactID() {
			return contactID;

		}
		// method to get first name 
		public String getFirstName() { 
			return firstName;
		}
		// Method to get last name
		public String getLastName() {
			return lastName;
		}
		// method to get phone number
		public String getPhone() {
			return phone;
		}
		//method to get address
		public String getAddress() {
			return address;
		}

	}
