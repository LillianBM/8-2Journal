import java.util.HashMap;
import java.util.Map;
// class for managing the contacts
public class ContactService {
	private Map<String, Contact> contacts; // map to store the contacts
	//Constructor to initialize the contacts map
	public ContactService() {
		contacts = new HashMap<>();
	}
	
	public void addContact(Contact contact) {
		contacts.put(contact.getContactID(),  contact);
	}
	public void deleteContact(String contactID) {
		contact.remove(contactID);
	}
	public void updateFirstName(String contactID, String newFirstName) {
		Contact contact = contacts.get(contact(ID);
		if (contact != null) {
			contact.firstName = newFirstName;
		}
	}
	public void updateLastName(String contactID, String newLastName) {
		Contact contact = contacts.get(ContactID);
		if (contact != null) {
			contact.lastName = newLastName;
		}
	}
	public void updatePhone(String contactID, String newPhone) {
		Contact contact = contacts.get(contactID);
		if (contact != null) {
			contact.phone = newPhone;
		}
	}
	public void updateAddress(String contactID, String newAddress) {
		Contact contact = contacts.get(contactID);
		if (contact != null) {
			contact.address = newAddress;
		}
	}
	public Contact getContact(String contactID) {
		return contacts.get(contactID);
	}

}
